import React from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';

const Container = styled.div`
  text-align: center;
  margin-top: 100px;

  h1 {
    font-size: 2rem;
    color: #333;
  }

  button {
    margin: 10px;
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;

    &:hover {
      background-color: #0056b3;
    }
  }
`;

const Home = () => {
  const navigate = useNavigate();

  return (
    <>
    <Container style={{backgroundColor:"beige"}}>
      <h1>Welcome to Store Rating App 🎯</h1>
      <button onClick={() => navigate('/register')}>Register</button>
      <button onClick={() => navigate('/login')}>Login</button>
    </Container>
    <img src='https://img.freepik.com/premium-vector/online-store-building_7737-788.jpg' style={{paddingLeft:"450px"}}></img>
    </>
    
    
  );
};

export default Home;
