import React from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';
import { getAllRatings } from '../services/api';
import  { useEffect, useState } from 'react';


const Container = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;
`;

const Card = styled.div`
  background-color: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  text-align: center;
  width: 80%;
  max-width: 400px;
`;

const Title = styled.h2`
  color: #333;
  margin-bottom: 20px;
`;

const Button = styled.button`
  padding: 10px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;

  &:hover {
    background-color: #0056b3;
  }
`;

const UserDashboard = () => {
  const navigate = useNavigate();

  const [ratings, setRatings] = useState([]);

  useEffect(() => {
    const fetchRatings = async () => {
      try {
        const response = await getAllRatings();
        setRatings(response.data);
      } catch (error) {
        console.error('Error fetching ratings:', error);
      }
    };

    fetchRatings();
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <Container>
      <Card>
        <Title>Welcome to User Dashboard 🎯</Title>
        <p>You are logged in as a User.</p>
        <div>
      <h2>Store Ratings</h2>
      <button >Rate</button>
      <ul>
        {ratings.map((rating) => (
          <li key={rating.id}>
            <strong>Store:</strong> {rating.store_name} | 
            <strong> User:</strong> {rating.user_name} | 
            <strong> Rating:</strong> {rating.rating}
          </li>
        ))}
      </ul>
    </div>
        <Button onClick={handleLogout}>Logout</Button>

      </Card>
      
    </Container>
  );
};

export default UserDashboard;
