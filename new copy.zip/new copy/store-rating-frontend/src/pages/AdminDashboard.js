import React from 'react';
import styled from 'styled-components';

const Container = styled.div`
  text-align: center;
  margin-top: 50px;
  font-size: 24px;
  color: #333;
`;

const AdminDashboard = () => {
  return <Container>Welcome to Admin Dashboard 🛡️</Container>;
};

export default AdminDashboard;
