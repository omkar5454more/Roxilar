import React, { useState } from 'react';
import { addRating } from '../services/api';

const RatingForm = ({ token, fetchRatings }) => {
  const [storeId, setStoreId] = useState('');
  const [rating, setRating] = useState('');

  const handleSubmit = async (e) => {
    console.log('Sending Data:', { storeId, rating });

    e.preventDefault();

    try {
      await addRating({ storeId, rating }, token);
      alert('Rating added successfully');
      fetchRatings(); // Refresh the ratings list after adding
      setStoreId('');
      setRating('');
    } catch (error) {
      console.error('Error adding rating:', error);
      alert('Failed to add rating');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        placeholder="Store ID"
        value={storeId}
        onChange={(e) => setStoreId(e.target.value)}
        required
      />
      <input
        type="number"
        placeholder="Rating (1-5)"
        value={rating}
        min="1"
        max="5"
        onChange={(e) => setRating(e.target.value)}
        required
      />
      <button type="submit">Add Rating</button>
    </form>
  );
};

export default RatingForm;
