import { jwtDecode } from 'jwt-decode'; // Correct import


export const getUserRole = () => {
  const token = localStorage.getItem('token');
  if (!token) return null;

  try {
    const decodedToken = jwtDecode(token);
    return decodedToken.role;
  } catch (error) {
    console.error('Invalid token:', error);
    return null;
  }
};
