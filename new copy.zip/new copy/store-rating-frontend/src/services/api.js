import axios from 'axios';

// Axios instance with base URL
const API = axios.create({
  baseURL: 'http://localhost:3000/api', // Backend URL
});

// Register user API
export const registerUser = (userData) => API.post('/register', userData);

// Login API
export const loginUser = (userData) => API.post('/login', userData);

// Fetch all ratings
export const getAllRatings = () => API.get('/ratings');

// Add a rating
export const addRating = (data, token) =>
  API.post('/ratings', data, {
    headers: { Authorization: `Bearer ${token}` },
  });

// Update a rating
export const updateRating = (data, token) =>
  API.put('/ratings', data, {
    headers: { Authorization: `Bearer ${token}` },
  });

// Delete a rating
export const deleteRating = (data, token) =>
  API.delete('/ratings', {
    headers: { Authorization: `Bearer ${token}` },
    data,
  });
