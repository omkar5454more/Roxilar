const express = require('express');
const ratingController = require('../controllers/ratingController');
const authenticateToken = require('../middlewares/authMiddleware');
const authorizeRoles = require('../middlewares/roleMiddleware');

const router = express.Router();

// Only 'user' can add, update, and delete ratings
router.post('/ratings', authenticateToken, authorizeRoles(['user']), ratingController.addRating);
router.put('/ratings', authenticateToken, authorizeRoles(['user']), ratingController.updateRating);
router.delete('/ratings', authenticateToken, authorizeRoles(['user']), ratingController.deleteRating);
router.get('/ratings', ratingController.getAllRatings);
// 'admin' and 'store_owner' can view store ratings
router.get('/ratings/:storeId', authenticateToken, authorizeRoles(['admin', 'store_owner']), ratingController.getStoreAverageRating);

module.exports = router;
