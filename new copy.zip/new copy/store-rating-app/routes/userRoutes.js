const express = require('express');
const userController = require('../controllers/userController');
const authenticateToken = require('../middlewares/authMiddleware');
const router = express.Router();
const authorizeRole = require('../middlewares/roleMiddleware');


// Register Route First
router.post('/register', userController.registerUser);
// Only Admin can access all users
router.get('/users', authenticateToken, authorizeRole(['admin']), userController.getAllUsers);

// Only User and Store Owner can update profiles
router.put('/profile', authenticateToken, authorizeRole(['user', 'store_owner']), userController.updateUserProfile);

// Only User can change password
router.put('/change-password', authenticateToken, authorizeRole(['user']), userController.changePassword);

// Other Routes
//  router.post('/users', userController.createUser);
router.post('/login', userController.loginUser);
 router.get('/users', userController.getAllUsers);
router.get('/users/:email', userController.findUserByEmail);
 router.put('/profile', authenticateToken, userController.updateUserProfile);
 router.put('/change-password', authenticateToken, userController.changePassword);

module.exports = router;
