const jwt = require('jsonwebtoken');
const secretKey = 'a3f5d8f9e789c12de45b9c1a3f4e8b12d8f5c3e8a9b12d8e7f5b3e8f1c3d7b2e'; // Use the same key from login

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  const token = authHeader.split(' ')[1];

  jwt.verify(token, secretKey, (err, decoded) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid token' });
    }
    req.user = decoded; // Store user info in request object
    next();
  });
};

module.exports = authenticateToken;
