const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const userRoutes = require('./routes/userRoutes');
const ratingRoutes = require('./routes/ratingRoutes');

const app = express();
const port = 3000;
const db = require('./config/db');

// Test the connection with a sample query
db.query('SELECT 1 + 1 AS result', (err, results) => {
  if (err) {
    console.error('Database query error:', err);
  } else {
    console.log('Database connection test result:', results[0].result);
  }
});


// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());


// Routes
app.use('/api', userRoutes);
app.use('/api', ratingRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
