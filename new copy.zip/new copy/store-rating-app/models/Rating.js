const db = require('../config/db');

const Rating = {
  addRating: (userId, storeId, rating, callback) => {
    const query = 'INSERT INTO ratings (user_id, store_id, rating) VALUES (?, ?, ?)';
    db.query(query, [userId, storeId, rating], callback);
  },
  updateRating: (userId, storeId, rating, callback) => {
    const query = 'UPDATE ratings SET rating = ? WHERE user_id = ? AND store_id = ?';
    db.query(query, [rating, userId, storeId], callback);
  },

  deleteRating: (userId, storeId, callback) => {
    const query = 'DELETE FROM ratings WHERE user_id = ? AND store_id = ?';
    db.query(query, [userId, storeId], callback);
  },


  getStoreRatings: (storeId, callback) => {
    const query = 'SELECT AVG(rating) AS averageRating FROM ratings WHERE store_id = ?';
    db.query(query, [storeId], callback);
  },
  getAllRatings: (limit, offset, callback) => {
    const query = `
      SELECT r.id, u.name AS user_name, s.name AS store_name, r.rating 
      FROM ratings r
      JOIN users u ON r.user_id = u.id
      JOIN stores s ON r.store_id = s.id
      LIMIT ? OFFSET ?
    `;
    db.query(query, [limit, offset], callback);
  }
};

module.exports = Rating;
