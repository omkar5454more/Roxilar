const db = require('../config/db');

const User = {
  create: (name, email, address, password, role, callback) => {
    const query = 'INSERT INTO users (name, email, address, password, role) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [name, email, address, password, role], callback);
  },

  findByEmail: (email, callback) => {
    const query = 'SELECT * FROM users WHERE email = ?';
    db.query(query, [email], callback);
  },

  getAllUsers: (callback) => {
    const query = 'SELECT * FROM users';
    db.query(query, callback);
  },
  updateUser: (userId, name, email, address, callback) => {
    const query = `
      UPDATE users 
      SET name = ?, email = ?, address = ?
      WHERE id = ?
    `;
    db.query(query, [name, email, address, userId], callback);
  },
  updatePassword: (userId, hashedPassword, callback) => {
    const query = `
      UPDATE users 
      SET password = ?
      WHERE id = ?
    `;
    db.query(query, [hashedPassword, userId], callback);
  }
  
};


module.exports = User;
