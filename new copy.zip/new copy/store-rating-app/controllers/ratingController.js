const Rating = require('../models/Rating');

const ratingController = {
  addRating: (req, res) => {
    const { userId, storeId, rating } = req.body;

    if (!userId || !storeId || !rating || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Invalid rating or missing data' });
    }

    Rating.addRating(userId, storeId, rating, (err, result) => {
      if (err) {
        console.error('Error adding rating:', err);
        return res.status(500).json({ message: 'Error adding rating' });
      }
      res.status(201).json({ message: 'Rating added successfully' });
    });
    console.log('Request Body:', req.body);
console.log('User ID from JWT:', req.user);

  },
  
  updateRating: (req, res) => {
    const { userId, storeId, rating } = req.body;

    if (!userId || !storeId || !rating || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Invalid rating or missing data' });
    }

    Rating.updateRating(userId, storeId, rating, (err, result) => {
      if (err) {
        console.error('Error updating rating:', err);
        return res.status(500).json({ message: 'Error updating rating' });
      }
      res.status(200).json({ message: 'Rating updated successfully' });
    });
  },
  
  deleteRating: (req, res) => {
    const { userId, storeId } = req.body;

    if (!userId || !storeId) {
      return res.status(400).json({ message: 'User ID and Store ID are required' });
    }

    Rating.deleteRating(userId, storeId, (err, result) => {
      if (err) {
        console.error('Error deleting rating:', err);
        return res.status(500).json({ message: 'Error deleting rating' });
      }
      res.status(200).json({ message: 'Rating deleted successfully' });
    });
  },


  getStoreAverageRating: (req, res) => {
    const { storeId } = req.params;

    Rating.getStoreRatings(storeId, (err, results) => {
      if (err) {
        console.error('Error fetching ratings:', err);
        return res.status(500).json({ message: 'Error fetching ratings' });
      }

      res.status(200).json({ averageRating: results[0].averageRating || 0 });
    });
  },

  getAllRatings: (req, res) => {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10; 
    const offset = (page - 1) * limit;
  
    Rating.getAllRatings(limit, offset, (err, results) => {
      if (err) {
        console.error('Error fetching ratings:', err);
        return res.status(500).json({ message: 'Error fetching ratings' });
      }
  
      res.status(200).json(results);
    });
  }
};

module.exports = ratingController;
