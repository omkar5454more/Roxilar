const bcrypt = require('bcrypt');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const secretKey = 'a3f5d8f9e789c12de45b9c1a3f4e8b12d8f5c3e8a9b12d8e7f5b3e8f1c3d7b2e'; // Replace with a strong secret

const userController = {
  // Register User with Role
  registerUser: async (req, res) => {
    const { name, email, address, password, role } = req.body;

    if (!name || !email || !password || !role) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const validRoles = ['user', 'admin', 'store_owner'];
    if (!validRoles.includes(role)) {
      return res.status(400).json({ message: 'Invalid role' });
    }

    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      User.create(name, email, address, hashedPassword, role, (err, result) => {
        if (err) {
          console.error('Error creating user:', err);
          return res.status(500).json({ message: 'Error creating user' });
        }
        res.status(201).json({ message: 'User registered successfully', userId: result.insertId });
      });
    } catch (error) {
      console.error('Password hashing error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  },

  // User Login
  loginUser: (req, res) => {
    const { email, password } = req.body;

    User.findByEmail(email, async (err, results) => {
      if (err) return res.status(500).json({ message: 'Error finding user' });

      if (results.length === 0) return res.status(404).json({ message: 'User not found' });

      const user = results[0];
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

      // Generate JWT token
      const token = jwt.sign({ userId: user.id, role: user.role }, secretKey, { expiresIn: '1h' });
      res.status(200).json({ message: 'Login successful', token });
    });
  },

  // Get all users
  getAllUsers: (req, res) => {
    User.getAllUsers((err, results) => {
      if (err) {
        console.error('Error fetching users:', err);
        return res.status(500).json({ message: 'Error fetching users' });
      }
      res.status(200).json(results);
    });
  },

  // Find user by email
  findUserByEmail: (req, res) => {
    const { email } = req.params;

    User.findByEmail(email, (err, results) => {
      if (err) {
        console.error('Error finding user:', err);
        return res.status(500).json({ message: 'Error finding user' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }
      res.status(200).json(results[0]);
    });
  },

  // Update User Profile
  updateUserProfile: (req, res) => {
    const userId = req.user.userId; // Extracted from JWT token
    const { name, email, address } = req.body;

    if (!name || !email || !address) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    User.updateUser(userId, name, email, address, (err) => {
      if (err) {
        console.error('Error updating user:', err);
        return res.status(500).json({ message: 'Error updating profile' });
      }

      res.status(200).json({ message: 'Profile updated successfully' });
    });
  },

  // Change Password
  changePassword: async (req, res) => {
    const userId = req.user.userId; // Extract from JWT token
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Both current and new passwords are required' });
    }

    // Fetch the user's current hashed password from the database
    User.findById(userId, async (err, results) => {
      if (err) {
        console.error('Error finding user:', err);
        return res.status(500).json({ message: 'Internal server error' });
      }

      if (results.length === 0) {
        return res.status(404).json({ message: 'User not found' });
      }

      const user = results[0];
      const isMatch = await bcrypt.compare(currentPassword, user.password);

      if (!isMatch) {
        return res.status(401).json({ message: 'Current password is incorrect' });
      }

      // Hash the new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update the password in the database
      User.updatePassword(userId, hashedPassword, (updateErr) => {
        if (updateErr) {
          console.error('Error updating password:', updateErr);
          return res.status(500).json({ message: 'Error updating password' });
        }

        res.status(200).json({ message: 'Password updated successfully' });
      });
    });
  },
  createUser: async (req, res) => {
    const { name, email, address, password, role } = req.body;
  
    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email, and password are required' });
    }
  
    try {
      const hashedPassword = await bcrypt.hash(password, 10);
      User.create(name, email, address, hashedPassword, role || 'user', (err, result) => {
        if (err) {
          console.error('Error creating user:', err);
          return res.status(500).json({ message: 'Error creating user' });
        }
        res.status(201).json({ message: 'User created successfully', userId: result.insertId });
      });
    } catch (error) {
      console.error('Password hashing error:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  }
  
};

module.exports = userController;
